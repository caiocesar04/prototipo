<?php
if(isset($_POST["acao"])){
	if($_POST["acao"] == "inserir"){
		inserirContato();
	}
	if($_POST["acao"] == "alterar"){
		alterarContato();
	}
	if($_POST["acao"] == "excluir"){
		excluirContato();
	}
}
function abrirBd(){
	$conexao = new mysqli("localhost", "root", "", "cadastro");
	return $conexao;
}
function inserirContato(){
	$banco = abrirBd();
	$sql = "INSERT INTO contato(nome, telefone,email,cpf,idade,nascimento)"
		." VALUES ('{$_POST["nome"]}','{$_POST["telefone"]}','{$_POST["email"]}','{$_POST["cpf"]}','{$_POST["idade"]}','{$_POST["nascimento"]}')"; 
	$banco->query($sql);
	$banco->close();
	voltarIndex();
}
function alterarContato(){
	$banco = abrirBd();
	$sql = "UPDATE contato SET nome='{$_POST["nome"]}' , "." telefone='{$_POST["telefone"]}' , "." email='{$_POST["email"]}' , "." cpf='{$_POST["cpf"]}'  , "." idade='{$_POST["idade"]}' , "." nascimento='{$_POST["nascimento"]}'     WHERE id='{$_POST["id"]}'";
	$banco->query($sql);
	$banco->close();
	voltarIndex();
}
function excluirContato(){
	$banco = abrirBd();
	$sql = "DELETE FROM contato WHERE id='{$_POST["id"]}'";
	$banco->query($sql);
	$banco->close();
	voltarIndex();
}
function selectAllContato(){
	$banco = abrirBd();
	$sql = "SELECT * FROM contato ORDER BY nome";
	$resultado = $banco->query($sql);
	while($row = mysqli_fetch_array($resultado)){
		$grupo[] = $row;
	}
	if(!empty($grupo)){
	return $grupo;
	}
}
function selectIdContato($id){
	$banco = abrirBd();
	$sql = "SELECT * FROM contato WHERE id =".$id;
	$resultado = $banco->query($sql);
	$pessoa = mysqli_fetch_assoc($resultado);
	return $pessoa;
}
function voltarIndex(){
	header("Location:sucesso.php");
}
?>