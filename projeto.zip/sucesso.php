<?php include("conexao.php");
	$grupo = selectAllContato();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	 
	<h1>Cadastro de Contatos</h1>
	<a href="inserir.php">Adicionar Contatos</a><br></br>
	<table border="10">
		<thead>
			<tr>
		 		<th>Id</th>
        		 <th>Nome</th>
        		 <th>Telefone</th>
	    		 <th>Email</th>
        		 <th>Cpf</th> 
				 <th>Idade</th>
				 <th>Nascimento</th>
				 <th>Editar</th>
		 		<th>Excluir</th>
			</tr>
		</thead>
		<tbody>
			<?php
				if(isset($grupo)){
				foreach ($grupo as $pessoa) { ?>
				<tr>
				<td><?=$pessoa["id"]?></td> 
					<td><?=$pessoa["nome"]?></td>
					<td><?=$pessoa["telefone"]?></td>
					<td><?=$pessoa["email"]?></td>
					<td><?=$pessoa["cpf"]?></td>
					<td><?=$pessoa["idade"]?></td>
             		<td><?=formatoData($pessoa["nascimento"])?></td>
					<td>
						<form name="alterar" action="alterar.php" method="POST"><input type="hidden" name="id" value=<?=$pessoa["id"]?> />
						<input type="submit" value="Editar" name="editar" />
						</form>
					</td>
					<td>
						<form name="excluir" action="conexao.php" method="POST">
							<input type="hidden" name="id" value="<?=$pessoa["id"]?>"/>
							<input type="hidden" name="acao" value="excluir"/>
							<input type="submit" value="Excluir" name="excluir"/>
						</form>
					</td>
				</tr>
				<?php }}
			?>
		</tbody>
	</table>
	<?php
		function formatoData($data){
			$array = explode("-", $data);
		
			$novaData = $array[2]."/".$array[1]."/".$array[0];
			return $novaData;
		}
	?>
</body>
</html>
<!DOCTYPE html>
<html> 
<link rel="stylesheet" type="text/css" href="style.css"/>

<body style="background-image: url(imgpadrao.png)">
</body>
</html>