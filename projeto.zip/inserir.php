<meta charset="utf-8">
<form name="dadosPessoa" action="conexao.php" method="POST">
	<table border="10">
		<tbody>
			<tr>
				<td>Nome:</td>
				<td><input type="text" name="nome" value=""></td>
			</tr>
			<tr>
				<td>Telefone:</td>
				<td><input type="text" name="telefone" value=""></td>
			</tr>
			<tr>
				<td>Email:</td>
				<td><input type="text" name="email" value=""></td>
			</tr>
			<tr>
				<td>Cpf:</td>
				<td><input type="text" name="cpf" value=""></td>
			</tr>
			<tr>
				<td>Idade:</td>
				<td><input type="text" name="idade" value=""></td>
			</tr>
			<tr>
				<td>Nascimento:</td>
				<td><input type="date" name="nascimento" value=""></td>
			</tr>
			<tr>
				<td>Enviar:</td>
				<input type="hidden" name="acao" value="inserir">
				<td><input type="submit" name="Enviar" value="Enviar"></td>
			</tr>
		</tbody>
	</table>
</form>
<!DOCTYPE html>
<html> 
<link rel="stylesheet" type="text/css" href="style.css"/>

<body style="background-image: url(imgpadrao.png)">
</body>
</html>