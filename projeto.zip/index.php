<?php

?>

<!DOCTYPE html>
<html> 
<link rel="stylesheet" type="text/css" href="style.css"/>
<h1> <div class="bem_vindo"> Bem Vindo! Anuncie seus produtos </div>             
        <div class="aqui">
        <a href="login.html"> aqui! </a>
      </h1> 
<body style="background-image: url(venda.png)">
</body>
</html>